Multi platform development

Mac OSX 10.9.5, Xcode 6+
Windows CodeBlocks

[33%]: 102070017 : Main, HeapType, HashTable
[33%]: 102070021 : Main, HeapType, HashTable
[33%]: x1030004  : HeapType, HashTable, Graph